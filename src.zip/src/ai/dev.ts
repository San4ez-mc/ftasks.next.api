import { config } from 'dotenv';
config();

import '@/ai/flows/ai-task-prioritization.ts';