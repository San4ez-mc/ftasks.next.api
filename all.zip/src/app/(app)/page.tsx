import TasksPage from "../page";

export default TasksPage;
